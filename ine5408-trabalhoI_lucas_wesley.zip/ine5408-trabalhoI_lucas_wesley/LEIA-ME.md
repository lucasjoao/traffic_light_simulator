Projeto de implementação número 1 - INE5408 - UFSC

Desenvolvido por Lucas João Martins e Wesley Mayk Gama Luz.

Para execução do projeto, deve ser compilado o arquivo main.cpp com o g++ e a flag -std=c++11. Por exemplo:
    g++ main.cpp -o executavel -std=c++11
